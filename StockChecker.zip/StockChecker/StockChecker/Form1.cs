﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Web;
using System.Windows.Forms;
using System.Net;
using System.Data;
using Newtonsoft.Json;

namespace StockChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string GetWebResponse(string url)
        {
            // Make a WebClient.
            WebClient web_client = new WebClient();

            // Get the indicated URL.
            Stream response = web_client.OpenRead(url);

            // Read the result.
            using (StreamReader stream_reader = new StreamReader(response))
            {
                // Get the results.
                string result = stream_reader.ReadToEnd();

                // Close the stream reader and its underlying stream.
                stream_reader.Close();

                // Return the result.
                return result;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string line = "";
            StreamReader file = new StreamReader("Ticker.txt");
                while (!file.EndOfStream)
                {
                    line += file.ReadLine() + "&"; //adding distinct value so that we can split them as a line.
                }
            string[] newLines = line.Split('&'); //storing lines in array.
            textBox1.Text = newLines[0].Split(':')[0].ToString();
            textBox2.Text = newLines[1].Split(':')[0].ToString();
            textBox3.Text = newLines[2].Split(':')[0].ToString();
            textBox4.Text = newLines[3].Split(':')[0].ToString(); 
            textBox5.Text = newLines[4].Split(':')[0].ToString();
            textBox6.Text = newLines[5].Split(':')[0].ToString();
            //var stocks = new List<String>
            //{
            //    textBox1.Text,
            //    textBox2.Text,
            //    textBox3.Text,
            //    textBox4.Text,
            //    textBox5.Text,
            //    textBox6.Text
            //};
            //System.IO.File.WriteAllLines("Ticker.txt", stocks);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var stocks = new List<String>
            {
                textBox1.Text,
                textBox2.Text,
                textBox3.Text,
                textBox4.Text,
                textBox5.Text,
                textBox6.Text
            };
            //string json = JsonConvert.SerializeObject(stocks);
            File.WriteAllLines("Ticker.txt", stocks);  //, JsonConvert.SerializeObject(stocks));
            //TextWriter File = new StreamWriter("Ticker.txt");
            //File.WriteLine(stocks);
            //File.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {


            //ProcessStartInfo startInfo = new ProcessStartInfo("iexplore.exe", "https://www.marketwatch.com/investing/stock/hog");
            //Process.Start(startInfo);

            //using (StreamReader sr = new StreamReader("Ticker.txt"))
            //{                                 
            //    string line;
            //    // Read and display lines from the file until the end of  
            //    // the file is reached. 
            //    while ((line = sr.ReadLine()) != null)
            //    {
            //        listBox1.Items.Add(line);
            //    }
            //    sr.Close();

            this.Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            // Build the URL.
            string url = "";
            if (textBox1.Text != "") url += textBox1.Text + "+";
            if (textBox2.Text != "") url += textBox2.Text + "+";
            if (textBox3.Text != "") url += textBox3.Text + "+";
            if (textBox4.Text != "") url += textBox4.Text + "+";
            if (textBox5.Text != "") url += textBox5.Text + "+";
            if (textBox6.Text != "") url += textBox6.Text + "+";

            if (url != "")
            {
                // Remove the trailing plus sign.
                url = url.Substring(0, url.Length - 1);

                // Prepend the base URL.
                const string base_url =
                    "https://www.marketwatch.com/investing/stock/@";
                url = base_url.Replace("@", url);

                // Get the response.
                try
                {

                    // Get the web response.
                    //string result = GetWebResponse(url);
                    //Console.WriteLine(result.Replace("\\r\\n", "\r\n"));

                    // Pull out the current prices.
                    string[] lines = url.Split(
                        new char[] { '\r', '\n' },
                        StringSplitOptions.RemoveEmptyEntries);
                    foreach (string line in lines)
                    {
                        //ProcessStartInfo startInfo = new ProcessStartInfo("iexplore.exe", "lines");
                        //Process.Start(startInfo); 
                        //dataGridView1.DataSource = line;
                        listBox1.Items.Add(line);    //decimal.Parse(lines[0].Split(',')[0]).ToString());
                    }

                    //txtPrice2.Text = decimal.Parse(lines[1].Split(',')[1]).ToString("C3");
                    //txtPrice3.Text = decimal.Parse(lines[2].Split(',')[1]).ToString("C3");
                    //txtPrice4.Text = decimal.Parse(lines[3].Split(',')[1]).ToString("C3");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Read Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }

            this.Cursor = Cursors.Default;
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("marvin.jpg");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
    }
}