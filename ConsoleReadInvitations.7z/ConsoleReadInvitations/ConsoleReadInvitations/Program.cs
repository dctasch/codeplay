﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;




namespace ConsoleReadInvitations
{
    class Program
    {
        static void Main(string[] args)
        {
            const string TEXT_FILE = "Invitations.txt";
                                 
            var linesRead = File.ReadAllLines(TEXT_FILE);
                      
            Array.Sort(linesRead);
                        
            foreach (string line in linesRead) 
            {
                               
                string[] parts = line.Split(' ');
                                                              
                StringBuilder nm = new StringBuilder();
                                
                for (int i = parts.Length - 1; i >= 0; i--)
                {
                    nm.Append(parts[i]);
                    nm.Append(" ");
                }
                
                nm.Replace("  ", string.Empty).Replace(" M ", "Mr. ").Replace(" F ", "Ms. ").Replace("Democrat", "Your Honarable Democrat: ").Replace("Republican", "Your Honarable Republican: ").Replace(",", ":"); 
                

                     Console.WriteLine("To: " + nm );
                                              
            }

            Console.ReadLine();
        }
    }
}



