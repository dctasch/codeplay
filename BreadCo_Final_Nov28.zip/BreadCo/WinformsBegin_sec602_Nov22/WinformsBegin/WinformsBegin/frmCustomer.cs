﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppHelper;
using System.IO;

namespace WinformsBegin
{
    public partial class frmCustomer : FormPlus
    {
        private List<Customer> listCust = null;

        const string XML_FILE = "customer.xml";

        public frmCustomer()
        {
            InitializeComponent();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            listCust = LoadData<List<Customer>>(XML_FILE);
            if (listCust == null) listCust = new List<Customer>();
            this.dgvCustomer.DataSource = listCust;
        }

        private void frmCustomer_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveData(listCust);
        }

        private void InputReset()
        {
            this.txtLastName.Text = "";
            this.txtFirstName.Text = "";
            this.txtEmail.Text = "";
            this.txtPhone.Text = "";

            this.txtLastName.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //CustomerCheck();

            if (editMode)
            {
                listCust[rowIndex].LastName = this.txtLastName.Text;
                listCust[rowIndex].FirstName = this.txtFirstName.Text;
                listCust[rowIndex].Email = this.txtEmail.Text;
                listCust[rowIndex].Phone = this.txtPhone.Text;
            }
            else
            {
                var customer = new Customer(this.txtFirstName.Text,
                    this.txtLastName.Text,
                    this.txtEmail.Text,
                    this.txtPhone.Text);

                listCust.Add(customer);
            }
          
            this.dgvCustomer.DataSource = null;
            this.dgvCustomer.DataSource = listCust;

            InputReset();

            editMode = false;
        }

        private bool CustomerCheck() 
        {
            errList.Clear();
            this.lblErrorLastName.Visible = false;
            this.lblErrorFirstName.Visible = false;

            string lastname = this.txtLastName.Text;

            if (lastname.Length == 0) {
                errList.Add("Last name must be entered.");
                this.lblErrorLastName.Visible = true;
            }

            string firstname = this.txtFirstName.Text;

            if (firstname.Length == 0) {
                errList.Add("First name must be entered.");
                this.lblErrorFirstName.Visible = true;
            }

            StringBuilder errs = new StringBuilder();

            foreach (var text in errList)
                errs.AppendLine(text);

            MessageBox.Show(errs.ToString());

            return true;
        }

        private void dgvCustomer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = this.dgvCustomer.Rows[e.RowIndex];

            this.txtLastName.Text = row.Cells[0].Value.ToString();
            this.txtFirstName.Text = row.Cells[1].Value.ToString();
            this.txtEmail.Text = row.Cells[2].Value.ToString();
            this.txtPhone.Text = row.Cells[3].Value.ToString();

            this.txtLastName.Focus();

            editMode = true;
            rowIndex = e.RowIndex;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (DeleteOK())
            {
                listCust.RemoveAt(rowIndex);
                this.dgvCustomer.DataSource = null;
                this.dgvCustomer.DataSource = listCust;
            }
        }

        private void dgvCustomer_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var listCustFilter = new List<Customer>();

            foreach (var cust in listCust)
            {
                if (cust.LastName.StartsWith(this.txtLastName.Text))
                    listCustFilter.Add(cust);
            }

            this.dgvCustomer.DataSource = null;
            this.dgvCustomer.DataSource = listCustFilter;
        }
    }
}
