﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppHelper;
using System.IO;

namespace WinformsBegin
{
    public partial class frmProduct : Form
    {
        private List<string> errList = new List<string>();

        private List<Product> listProduct = new List<Product>();

        const string XML_FILE = "products.xml";

        private XMLSerializer xml = null;

        private bool editMode = false;

        private int rowIndex = -1;

        public frmProduct()
        {
            InitializeComponent();
        }

        private void SaveData() 
        {
            xml.SaveData(listProduct);
        }
        private void LoadData()
        {
            xml = new XMLSerializer(XML_FILE);

            if (!File.Exists(xml.XMLPath))
                xml.SaveData(listProduct);

            listProduct.Clear();
            listProduct = xml.LoadData<List<Product>>();

            this.dgvProduct.DataSource = null;
            this.dgvProduct.DataSource = listProduct;

        }

        private void InputReset()
        {
            this.txtProductCode.Text = "";
            this.txtDescription.Text = "";
            this.txtPrice.Text = "";

            this.txtProductCode.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //CustomerCheck();

            if (editMode)
            {
                listProduct[rowIndex].ProdCode = this.txtProductCode.Text;
                listProduct[rowIndex].Description = this.txtDescription.Text;
                listProduct[rowIndex].Price = Convert.ToDecimal(this.txtPrice.Text);
            }
            else
            {
                var product = new Product(this.txtProductCode.Text,
                    this.txtDescription.Text,
                    Convert.ToDecimal(this.txtPrice.Text)
                    );

                listProduct.Add(product);
            }
          

            this.dgvProduct.DataSource = null;
            this.dgvProduct.DataSource = listProduct;

            InputReset();

            editMode = false;
        }

        private bool CustomerCheck() 
        {
            errList.Clear();
            this.lblErrorLastName.Visible = false;
            this.lblErrorFirstName.Visible = false;


            string lastname = this.txtProductCode.Text;

            if (lastname.Length == 0) {
                errList.Add("Last name must be entered.");
                this.lblErrorLastName.Visible = true;
            }

            string firstname = this.txtDescription.Text;

            if (firstname.Length == 0) {
                errList.Add("First name must be entered.");
                this.lblErrorFirstName.Visible = true;
            }

            StringBuilder errs = new StringBuilder();

            foreach (var text in errList)
                errs.AppendLine(text);

            MessageBox.Show(errs.ToString());

            return true;
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void txtLastName_Validated(object sender, EventArgs e)
        {
            //string lastname = this.txtLastName.Text;

            //if (lastname.Length == 0)
            //{
            //    MessageBox.Show("Last name must be entered.");
            //    this.txtLastName.Focus();
            //}

        }

        private void frmCustomer_FormClosing(object sender, FormClosingEventArgs e) 
        {
            SaveData();
            //SaveDataCustomer();
        }

        private void dgvCustomer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = this.dgvProduct.Rows[e.RowIndex];

            this.txtProductCode.Text = row.Cells[0].Value.ToString();
            this.txtDescription.Text = row.Cells[1].Value.ToString();
            this.txtPrice.Text = row.Cells[2].Value.ToString();

            this.txtProductCode.Focus();

            editMode = true;
            rowIndex = e.RowIndex;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (rowIndex == -1) return;

            DialogResult dialogResult = 
                MessageBox.Show("Are you sure?", 
                "Please Confirm", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                listProduct.RemoveAt(rowIndex);
                this.dgvProduct.DataSource = null;
                this.dgvProduct.DataSource = listProduct;
            }
        }

        private void dgvCustomer_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var listProdFilter = new List<Product>();

            foreach (var cust in listProduct)
            {
                if (cust.ProdCode.StartsWith(this.txtProductCode.Text))
                    listProdFilter.Add(cust);
            }

            this.dgvProduct.DataSource = null;
            this.dgvProduct.DataSource = listProdFilter;
        }
    }
}
