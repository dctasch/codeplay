﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformsBegin
{
    public class LineItem
    {
        public string Description { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public decimal TotalPrice { get; set; }

        public LineItem(string description,
            decimal unitPrice,
            decimal quantity)
        {
            this.Description = description;
            this.UnitPrice = unitPrice;
            this.Quantity = quantity;
            this.TotalPrice = quantity * unitPrice;
        }

        public LineItem()
        {

        }
    }
}
