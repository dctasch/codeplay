﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformsBegin {
    public class Product 
    {
        public string ProdCode { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }

        public Product(string prodCode, string description, 
            decimal price) 
        {
            this.ProdCode = prodCode;
            this.Description = description;
            this.Price = price;
        }

        public Product()
        {

        }

        public override string ToString()
        {
            return $"{this.Description}: {this.Price}";
        }
    }
}
