﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformsBegin
{
    public class Order
    {
        public string CustName { get; set; }
        public string EmpName { get; set; }
        public string OrderNo { get; set; }
        public DateTime OrderTS { get; set; }
        public decimal OrderTotal { get; set; }
        public List<LineItem> LineItems { get; set; }

        public Order(string custName,
            string empName,
            string orderNo,
            DateTime orderTS,
            decimal orderTotal,
            List<LineItem> lineItems)
        {
            this.CustName = custName;
            this.EmpName = empName;
            this.OrderNo = orderNo;
            this.OrderTS = orderTS;
            this.OrderTotal = orderTotal;
            this.LineItems = lineItems;
        }

        public Order()
        {

        }
    }
}
