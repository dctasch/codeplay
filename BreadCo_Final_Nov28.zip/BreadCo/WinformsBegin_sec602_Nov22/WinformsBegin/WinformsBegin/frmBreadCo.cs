﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinformsBegin
{
    public partial class frmBreadCo : Form
    {
        public frmBreadCo()
        {
            InitializeComponent();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
        }

        private void frmBreadCo_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Loading...");
        }

        private void frmBreadCo_FormClosing(object sender, FormClosingEventArgs e)
        {
            //MessageBox.Show("Closing, better save data!");

        }

        private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmOrders = new frmOrders();
            frmOrders.ShowDialog();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmCust = new frmCustomer();
            frmCust.ShowDialog();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmProd = new frmProduct();
            frmProd.ShowDialog();
        }

        private void kitchenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmKitch = new frmKitchen();
            frmKitch.ShowDialog();
        }

        private void employeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmEmp = new frmEmployee();
            frmEmp.ShowDialog();
        }
    }
}
