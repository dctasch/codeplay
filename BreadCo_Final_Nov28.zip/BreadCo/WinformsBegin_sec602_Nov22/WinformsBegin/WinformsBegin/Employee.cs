﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformsBegin {
    public class Employee 
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Position { get; set; }

        public Employee(string firstName, string lastName, string position) 
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Position = position;
        }

        public Employee()
        {

        }

        public override string ToString()
        {
            return $"{LastName}, {FirstName}";
        }
    }
}
