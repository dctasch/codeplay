﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using AppHelper;

namespace WinformsBegin
{
    public partial class frmOrders : FormPlus
    {
        //TODO: add employee information

        private List<Customer> listCust = new List<Customer>();
        private List<Employee> listEmp = new List<Employee>();
        private List<Product> listProd = new List<Product>();
        private List<LineItem> listLineItem = new List<LineItem>();
        private List<Order> listOrder = new List<Order>();

        const string CUST_XML_FILE = "customer.xml";
        const string EMPL_XML_FILE = "employee.xml";
        const string PROD_XML_FILE = "products.xml";
        const string ITEM_XML_FILE = "lineitems.xml";
        const string ORDR_XML_FILE = "orders.xml";

        decimal orderTotal = 0.00m;

        private void LoadData()
        {
            listCust = LoadData<List<Customer>>(CUST_XML_FILE);
            this.cboCustomers.DataSource = listCust;

            listEmp = LoadData<List<Employee>>(EMPL_XML_FILE);
            this.cboEmployees.DataSource = listEmp;

            listProd = LoadData<List<Product>>(PROD_XML_FILE);
            this.cboProduct.DataSource = listProd;
        }
        public frmOrders()
        {
            InitializeComponent();
        }

        private void frmOrders_Load(object sender, EventArgs e)
        {
            LoadData();
            this.timer1.Interval = 1000;
            this.timer1.Enabled = true;
        }

        private void btnAddLineItem_Click(object sender, EventArgs e)
        {
            var selectedProduct = this.cboProduct.SelectedItem as Product;

            var lineItem = new LineItem(selectedProduct.Description,
                selectedProduct.Price,
                this.nudQuantity.Value);

            listLineItem.Add(lineItem);

            ListLineItems();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            var customer = this.cboCustomers.SelectedItem as Customer;

            var employee = this.cboEmployees.SelectedItem as Employee;

            var order = new Order(customer.FirstName, employee.ToString(), this.txtOrderNo.Text, DateTime.Now,
                orderTotal, listLineItem);

            //pull in previous orders, check for null
            var previousData = LoadData<List<Order>>(ORDR_XML_FILE);

            //Check to for null orders
            if (previousData != null) listOrder.AddRange(previousData);

            //add new order
            listOrder.Add(order);

            //resave all orders
            SaveData(listOrder);

            MessageBox.Show("Order placed.", "Success!");

            //erase previous order information and get ready for next order.
            InitializeOrder();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.lblDateTime.Text = DateTime.Now.ToShortTimeString();
        }

        private void btnDeleteLineItem_Click(object sender, EventArgs e)
        {
            if (DeleteOK())
            {
                listLineItem.RemoveAt(rowIndex);
                ListLineItems();
            }
        }

        private void dgvLineItems_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
        }

        private void InitializeOrder()
        {
            this.listOrder.Clear();
            this.cboCustomers.SelectedIndex = -1;
            this.cboProduct.SelectedIndex = -1;
            this.nudQuantity.Value = 1;
            this.txtOrderNo.Text = "";
            this.txtOrderTotal.Text = "";
            this.btnPlaceOrder.Enabled = false;
            listLineItem.Clear();
            ListLineItems();
            this.cboCustomers.Focus();
        }

        private void ListLineItems()
        {
            orderTotal = 0.0m;

            foreach (var li in listLineItem)
                orderTotal += li.TotalPrice;

            this.txtOrderTotal.Text = orderTotal.ToString();

            this.dgvLineItems.DataSource = null;
            this.dgvLineItems.DataSource = listLineItem;
            this.dgvLineItems.AutoResizeColumns();

            foreach (var i in new List<int> { 1, 2, 3 })
                this.dgvLineItems.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            this.btnPlaceOrder.Enabled = this.btnDeleteLineItem.Enabled = listLineItem.Count > 0;
        }
    }
}
