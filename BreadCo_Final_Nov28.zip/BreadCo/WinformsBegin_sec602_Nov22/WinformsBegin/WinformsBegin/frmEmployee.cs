﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppHelper;
using System.IO;

namespace WinformsBegin
{
    public partial class frmEmployee : FormPlus
    {
        private List<Employee> listEmp = null;

        const string XML_FILE = "employee.xml";

        public frmEmployee()
        {
            InitializeComponent();
        }

        private void frmEmployee_Load(object sender, EventArgs e)
        {
            //var previousData = LoadData<List<Order>>(ORDR_XML_FILE);

            ////Check to for null orders
            //if (previousData != null) listOrder.AddRange(previousData);

            listEmp = LoadData<List<Employee>>(XML_FILE);
            if (listEmp == null) listEmp = new List<Employee>();
            this.dgvEmployee.DataSource = listEmp;
        }

        private void frmEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveData(listEmp);
        }
        private void dgvEmployee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = this.dgvEmployee.Rows[e.RowIndex];

            this.txtLastName.Text = row.Cells[0].Value.ToString();
            this.txtFirstName.Text = row.Cells[1].Value.ToString();
            this.txtPosition.Text = row.Cells[2].Value.ToString();

            this.txtLastName.Focus();

            editMode = true;
            rowIndex = e.RowIndex;
        }

        private void dgvEmployee_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
        }
        private void InputReset()
        {
            this.txtLastName.Text = "";
            this.txtFirstName.Text = "";
            this.txtPosition.Text = "";

            this.txtLastName.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //CustomerCheck();

            if (editMode)
            {
                listEmp[rowIndex].LastName = this.txtLastName.Text;
                listEmp[rowIndex].FirstName = this.txtFirstName.Text;
                listEmp[rowIndex].Position = this.txtPosition.Text;
            }
            else
            {
                var employee = new Employee(this.txtFirstName.Text,
                    this.txtLastName.Text,
                    this.txtPosition.Text);

                listEmp.Add(employee);
            }
          
            this.dgvEmployee.DataSource = null;
            this.dgvEmployee.DataSource = listEmp;

            InputReset();

            editMode = false;
        }

        private bool CustomerCheck() 
        {
            errList.Clear();
            this.lblErrorLastName.Visible = false;
            this.lblErrorFirstName.Visible = false;

            string lastname = this.txtLastName.Text;

            if (lastname.Length == 0) {
                errList.Add("Last name must be entered.");
                this.lblErrorLastName.Visible = true;
            }

            string firstname = this.txtFirstName.Text;

            if (firstname.Length == 0) {
                errList.Add("First name must be entered.");
                this.lblErrorFirstName.Visible = true;
            }

            StringBuilder errs = new StringBuilder();

            foreach (var text in errList)
                errs.AppendLine(text);

            MessageBox.Show(errs.ToString());

            return true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (rowIndex == -1) return;

            DialogResult dialogResult = 
                MessageBox.Show("Are you sure?", 
                "Please Confirm", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                listEmp.RemoveAt(rowIndex);
                this.dgvEmployee.DataSource = null;
                this.dgvEmployee.DataSource = listEmp;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var listEmpFilter = new List<Employee>();

            foreach (var emp in listEmp)
            {
                if (emp.LastName.StartsWith(this.txtLastName.Text))
                    listEmpFilter.Add(emp);
            }

            this.dgvEmployee.DataSource = null;
            this.dgvEmployee.DataSource = listEmpFilter;
        }

    }
}
