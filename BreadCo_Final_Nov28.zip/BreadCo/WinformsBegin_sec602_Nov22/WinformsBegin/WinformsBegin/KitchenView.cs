﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformsBegin
{
    public class KitchenView
    {
        public string Description { get; set; }
        public bool Completed { get; set; } = false;

        public KitchenView(string description)
        {
            this.Description = description;
        }

        public KitchenView()
        {

        }

        public override string ToString()
        {
            return $"{Description}";
        }

    }
}
