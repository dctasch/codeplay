﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinformsBegin
{
    public partial class frmKitchen : FormPlus
    {
        private List<Order> listOrder = null;
        private List<KitchenView> listKitchenView = null;

        const string XML_ORDERS = "orders.xml";
        const string XML_KITCHEN = "kitchen.xml";

        public frmKitchen()
        {
            InitializeComponent();
        }

        private void frmKitchen_Load(object sender, EventArgs e)
        {
            listOrder = LoadData<List<Order>>(XML_ORDERS);
            if (listOrder == null) listOrder = new List<Order>();

            //load previous values of KitchenView
            listKitchenView = LoadData<List<KitchenView>>(XML_KITCHEN);
            if (listKitchenView == null) listKitchenView = new List<KitchenView>();

            //convert order data to KitchenView
            foreach (var order in listOrder)
            {
                foreach (var li in order.LineItems)
                {
                    var description = new StringBuilder();
                    description.Append($"{order.CustName} -> {order.OrderNo} ({order.OrderTS.ToShortTimeString()}) ");
                    description.Append($"{li.Quantity} x {li.Description}");
                    listKitchenView.Add(new KitchenView(description.ToString()));
                }
            }

            this.lstOrdered.Items.AddRange(listKitchenView.ToArray());

            //return;     //TODO: for testing!!!

            //erase order data
            listOrder.Clear();
            SaveData(listOrder); 
        }

        private void frmKitchen_FormClosing(object sender, FormClosingEventArgs e)
        {
            //save KitchenView data
            listKitchenView.Clear();
            foreach (var item in this.lstOrdered.Items)
            {
                listKitchenView.Add(item as KitchenView);
            } 

            foreach (var item in this.lstPrepared.Items)
            {
                var kv = item as KitchenView;
                kv.Completed = true;
                listKitchenView.Add(item as KitchenView);
            }

            SaveData(listKitchenView);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            this.lstPrepared.Items.Clear();
        }

        private void btnMoveRight_Click(object sender, EventArgs e)
        {
            MoveListBoxItem(this.lstOrdered, this.lstPrepared);
        }

        private void btnMoveLeft_Click(object sender, EventArgs e)
        {
            MoveListBoxItem(this.lstPrepared, this.lstOrdered);
        }
        private void lstOrdered_DoubleClick(object sender, EventArgs e)
        {
            MoveListBoxItem(this.lstOrdered, this.lstPrepared);
        }

        private void lstPrepared_DoubleClick(object sender, EventArgs e)
        {
            MoveListBoxItem(this.lstPrepared, this.lstOrdered);
        }
        private void MoveListBoxItem(ListBox lstFrom, ListBox lstTo)
        {
            if (lstFrom.SelectedIndex == -1) return;
            var kv = lstFrom.SelectedItem as KitchenView;
            lstTo.Items.Add(kv);
            lstFrom.Items.RemoveAt(lstFrom.SelectedIndex);
        }
    }
}
