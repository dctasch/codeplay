﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace customer_form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I've been clicked!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim()==String.Empty)
            {
                MessageBox.Show("Please Enter Your Name.");
                txtName.Focus();
            }
            else
            {
                MessageBox.Show("You Entered Your Name");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Add some data to the combo box
            comboBox1.Items.Add("Microsoft");
            comboBox1.Items.Add("Google");
            comboBox1.Items.Add("Oracle");
            comboBox1.Items.Add("IBM");


        }

        private void button4_Click(object sender, EventArgs e)
        {
            lstView1.Items.Add("Dan");
            lstView1.Items[0].SubItems.Add("Brown");
            lstView1.Items.Add("Tom");
            lstView1.Items[1].SubItems.Add("Brady");
        }
    }
}
