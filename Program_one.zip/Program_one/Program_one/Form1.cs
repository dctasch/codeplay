﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_one
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {

        }

        private void lstproducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
