﻿namespace StockChecker
{
    internal class JsonSerializer
    {
        public JsonSerializer()
        {
            
        }
    }
}