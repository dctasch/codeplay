﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StockChecker
{
    public class Stock
    {
        public string Ticker { get; set; }
       
        public Stock(string ticker)
        {
            this.Ticker = ticker;
            
        }

        public override string ToString()
        {
            return Ticker;
        }

    }
}
