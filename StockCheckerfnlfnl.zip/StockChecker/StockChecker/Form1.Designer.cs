﻿namespace StockChecker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stkLUBtn4 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtStock6 = new System.Windows.Forms.TextBox();
            this.txtStock5 = new System.Windows.Forms.TextBox();
            this.txtStock4 = new System.Windows.Forms.TextBox();
            this.txtStock3 = new System.Windows.Forms.TextBox();
            this.txtStock2 = new System.Windows.Forms.TextBox();
            this.flCreateBtn3 = new System.Windows.Forms.Button();
            this.stkDspBtn2 = new System.Windows.Forms.Button();
            this.stkRecBtn1 = new System.Windows.Forms.Button();
            this.txtStock1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Lavender;
            this.groupBox1.Controls.Add(this.stkLUBtn4);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.txtStock6);
            this.groupBox1.Controls.Add(this.txtStock5);
            this.groupBox1.Controls.Add(this.txtStock4);
            this.groupBox1.Controls.Add(this.txtStock3);
            this.groupBox1.Controls.Add(this.txtStock2);
            this.groupBox1.Controls.Add(this.flCreateBtn3);
            this.groupBox1.Controls.Add(this.stkDspBtn2);
            this.groupBox1.Controls.Add(this.stkRecBtn1);
            this.groupBox1.Controls.Add(this.txtStock1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 237);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // stkLUBtn4
            // 
            this.stkLUBtn4.BackColor = System.Drawing.Color.Plum;
            this.stkLUBtn4.Location = new System.Drawing.Point(311, 40);
            this.stkLUBtn4.Name = "stkLUBtn4";
            this.stkLUBtn4.Size = new System.Drawing.Size(134, 23);
            this.stkLUBtn4.TabIndex = 20;
            this.stkLUBtn4.Text = "Stock Symbol Lookup ";
            this.stkLUBtn4.UseVisualStyleBackColor = false;
            this.stkLUBtn4.Click += new System.EventHandler(this.button4_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 120);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(299, 108);
            this.listBox1.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(311, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 152);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // txtStock6
            // 
            this.txtStock6.BackColor = System.Drawing.Color.Linen;
            this.txtStock6.Location = new System.Drawing.Point(73, 94);
            this.txtStock6.MaxLength = 4;
            this.txtStock6.Name = "txtStock6";
            this.txtStock6.Size = new System.Drawing.Size(61, 20);
            this.txtStock6.TabIndex = 7;
            // 
            // txtStock5
            // 
            this.txtStock5.BackColor = System.Drawing.Color.Linen;
            this.txtStock5.Location = new System.Drawing.Point(73, 66);
            this.txtStock5.MaxLength = 4;
            this.txtStock5.Name = "txtStock5";
            this.txtStock5.Size = new System.Drawing.Size(61, 20);
            this.txtStock5.TabIndex = 6;
            // 
            // txtStock4
            // 
            this.txtStock4.BackColor = System.Drawing.Color.Linen;
            this.txtStock4.Location = new System.Drawing.Point(73, 35);
            this.txtStock4.MaxLength = 4;
            this.txtStock4.Name = "txtStock4";
            this.txtStock4.Size = new System.Drawing.Size(61, 20);
            this.txtStock4.TabIndex = 5;
            // 
            // txtStock3
            // 
            this.txtStock3.BackColor = System.Drawing.Color.Linen;
            this.txtStock3.Location = new System.Drawing.Point(6, 94);
            this.txtStock3.MaxLength = 4;
            this.txtStock3.Name = "txtStock3";
            this.txtStock3.Size = new System.Drawing.Size(61, 20);
            this.txtStock3.TabIndex = 4;
            // 
            // txtStock2
            // 
            this.txtStock2.BackColor = System.Drawing.Color.Linen;
            this.txtStock2.Location = new System.Drawing.Point(6, 66);
            this.txtStock2.MaxLength = 4;
            this.txtStock2.Name = "txtStock2";
            this.txtStock2.Size = new System.Drawing.Size(61, 20);
            this.txtStock2.TabIndex = 3;
            // 
            // flCreateBtn3
            // 
            this.flCreateBtn3.BackColor = System.Drawing.Color.Coral;
            this.flCreateBtn3.Location = new System.Drawing.Point(140, 35);
            this.flCreateBtn3.Name = "flCreateBtn3";
            this.flCreateBtn3.Size = new System.Drawing.Size(72, 79);
            this.flCreateBtn3.TabIndex = 8;
            this.flCreateBtn3.Text = "ADD\r\nyour stocks to a file";
            this.flCreateBtn3.UseVisualStyleBackColor = false;
            this.flCreateBtn3.Click += new System.EventHandler(this.button3_Click);
            // 
            // stkDspBtn2
            // 
            this.stkDspBtn2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.stkDspBtn2.Location = new System.Drawing.Point(218, 63);
            this.stkDspBtn2.Name = "stkDspBtn2";
            this.stkDspBtn2.Size = new System.Drawing.Size(87, 51);
            this.stkDspBtn2.TabIndex = 9;
            this.stkDspBtn2.Text = "GET STOCK Information\r\nDisplay URL String";
            this.stkDspBtn2.UseVisualStyleBackColor = false;
            this.stkDspBtn2.Click += new System.EventHandler(this.button2_Click);
            // 
            // stkRecBtn1
            // 
            this.stkRecBtn1.BackColor = System.Drawing.Color.LightGreen;
            this.stkRecBtn1.Location = new System.Drawing.Point(152, 11);
            this.stkRecBtn1.Name = "stkRecBtn1";
            this.stkRecBtn1.Size = new System.Drawing.Size(281, 23);
            this.stkRecBtn1.TabIndex = 19;
            this.stkRecBtn1.Text = "Recall Previously saved Stocks ";
            this.stkRecBtn1.UseVisualStyleBackColor = false;
            this.stkRecBtn1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtStock1
            // 
            this.txtStock1.BackColor = System.Drawing.Color.Linen;
            this.txtStock1.Location = new System.Drawing.Point(6, 35);
            this.txtStock1.MaxLength = 4;
            this.txtStock1.Name = "txtStock1";
            this.txtStock1.Size = new System.Drawing.Size(61, 20);
            this.txtStock1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Stock Ticker Symbol";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 261);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "StockChecker";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button flCreateBtn3;
        private System.Windows.Forms.Button stkDspBtn2;
        private System.Windows.Forms.Button stkRecBtn1;
        private System.Windows.Forms.TextBox txtStock1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtStock6;
        private System.Windows.Forms.TextBox txtStock5;
        private System.Windows.Forms.TextBox txtStock4;
        private System.Windows.Forms.TextBox txtStock3;
        private System.Windows.Forms.TextBox txtStock2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button stkLUBtn4;
    }
}

