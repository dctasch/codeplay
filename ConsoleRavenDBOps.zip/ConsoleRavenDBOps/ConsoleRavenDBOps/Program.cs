﻿using Raven.Client.Document;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleRavenDBOps
{
    class Program
    {
        static void Main(string[] args)
        {
            var documentStore = new DocumentStore
            {
                Url = "http://localhost:8080"
            };
            documentStore.Initialize();

            using (var session = documentStore.OpenSession())
            {
                // Using the session
                session.Store(new Menu
                {
                    Name = "Breakfast Menu",
                    Courses = {
                        new Course {
                            Name = "Waffle",
                            Cost = 2.3m
                        },
                        new Course {
                                Name = "Cereal",
                                Cost = 1.3m,
                                Allergenics = { "Peanuts" }
                        },
                   }
                });

                session.SaveChanges();
            }
        }
    }

    public class Menu
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<Course> Courses { get; set; }
    }

    public class Course
    {
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public List<string> Allergenics { get; set; }
    }
}
