﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace CustomerData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         private void comTitle_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void txtFirstN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLastN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAdd_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void mtxtZipCode_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
        
        private void comState_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            

        }
// attempting to do something with a check box.  I want to improve this to make it disable the form if already a member.  For now it just prompts with message box verbage.
        private void cbMember_CheckedChanged(object sender, EventArgs e)
        {
            if (cbMember.Checked == true)
            {
                cbNonmember.Checked = false;
                MessageBox.Show("Thank you for being a loyal customers.  No need to fill in the form.  Mention the words RETURN VISIT to the cashier to enjoy a 5% discount on your total order.");                
            }
           
            if (cbMember.Checked == false)
            {
                MessageBox.Show("Please check one of the available boxes.");  
            }

        }
        private void cbNonmember_CheckedChanged(object sender, EventArgs e)
        {
            if (cbNonmember.Checked == true)
            {
                cbMember.Checked = false;
                MessageBox.Show("Welcome new member, we look forward to making your experience great.  Please complete the following fields for future rewards");
            }

            
            if (cbNonmember.Checked == false)
            {
                MessageBox.Show("Please check one of the available check boxes.");

            }
        }
        //Used a masked text box to set the zip field but did not get it to fail on improper info.  I do general check of all completed fields but not format. 
        private void buttonSave_Click(object sender, EventArgs e)
        {
            
            bool flag = true;

            foreach (Control cont in this.Controls)
            {
                if (cont is TextBox)
                {
                    TextBox tb = (TextBox)cont;
                    if (tb != null && tb.Text != "")
                    {
                        flag = flag && true;
                    }
                    else
                    {
                        flag = flag && false;
                    }       
                                      
                }
                else if (cont is ComboBox)
                {
                    ComboBox cb = (ComboBox)cont;
                    if (cb != null && Convert.ToString(cb.SelectedItem) != "")
                    {
                        flag = flag && true;
                    }
                    else
                    {
                        flag = flag && false;
                    }
                }
            }
            
            if (flag)
            {
                MessageBox.Show("Thank you for completing the form");
            }
            else
            {
                MessageBox.Show("please complete the form so we can reward you in the future");
            }
            //This creates the json file but i need to work on the formatting
            var clients = new List<String>
            {
                comTitle.Text,
                txtFirstN.Text,
                txtLastN.Text,
                txtAdd.Text,
                txtCity.Text,
                mtxtZipCode.Text,
                comState.Text,
                txtEmail.Text
            };
            string json = JsonConvert.SerializeObject(clients);
            File.AppendAllText("CustomerData.txt", JsonConvert.SerializeObject(clients));            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        // wanted a way to just close the form 
        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // I wanted to do a reset instead of making it part of the submit action.  
        private void buttonReset_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
    }
}
