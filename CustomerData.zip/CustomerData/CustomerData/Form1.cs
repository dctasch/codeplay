﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace CustomerData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         private void comTitle_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void txtFirstN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLastN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAdd_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void mtxtZipCode_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
        
        private void comState_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            

        }
// attempting to do something with a check box.  I want to improve this to make it disable the form if already a member.  For now it just prompts with message box verbage.
        private void cbMember_CheckedChanged(object sender, EventArgs e)
        {
            if (cbMember.Checked == true)
            {
                cbNonmember.Checked = false;
                MessageBox.Show("Thank you for being a loyal customers.  No need to fill in the form.  Mention the words RETURN VISIT to the cashier to enjoy a 5% discount on your total order.");                
            }
           
            if (cbMember.Checked == false)
            {
                MessageBox.Show("Please check one of the available boxes.");  
            }

        }
        private void cbNonmember_CheckedChanged(object sender, EventArgs e)
        {
            if (cbNonmember.Checked == true)
            {
                cbMember.Checked = false;
                MessageBox.Show("Welcome new member, we look forward to making your experience great.  Please complete the following fields for future rewards");
            }

            
            if (cbNonmember.Checked == false)
            {
                MessageBox.Show("Please check one of the available check boxes.");

            }
        }
        //Used a masked text box to set the zip field but did not get it to fail on improper info.  I do general check of all completed fields but not format. 
        private void buttonSave_Click(object sender, EventArgs e)
        {
            var errors = Validate();

            if (errors.Any())
            {
                var sb = new StringBuilder();
                sb.AppendLine("The following errors were found:");
                foreach (string s in errors)
                {
                    sb.AppendLine(s);
                }
                MessageBox.Show(sb.ToString());
                return;
            }
        }

        private new IEnumerable<string> Validate()
        {
            string email=txtEmail.Text;
            //pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
                       
            if (String.IsNullOrEmpty(txtFirstN.Text))
            {
                yield return "First Name Required";
            }
            if (String.IsNullOrEmpty(comTitle.Text))
            {
                yield return "Please choose Salutation";
            }
            if (String.IsNullOrEmpty(comState.Text))
            {
                yield return "Please select your home State";
            }
            if (String.IsNullOrEmpty(txtLastN.Text))
            {
                yield return "Last Name Required";
            }
            if (String.IsNullOrEmpty(txtCity.Text))
            {
                yield return "City Name Required";
            }
            if (String.IsNullOrEmpty(mtxtZipCode.Text))
            {
                yield return "Five Digit Zip Code Required";
            }
            if (String.IsNullOrEmpty(txtAdd.Text))
            {
                yield return "Address missing";
            }
            //if (email.LastIndexOf("@")>-1)  //
            //{
            //    yield return "Valid Email";                
            //}
            if (String.IsNullOrEmpty(txtEmail.Text))
            {
                yield return "Email Missing";
            }       
            var clients = new List<String>
            {
                comTitle.Text,
                txtFirstN.Text,
                txtLastN.Text,
                txtAdd.Text,
                txtCity.Text,
                mtxtZipCode.Text,
                comState.Text,
                txtEmail.Text
            };
            string json = JsonConvert.SerializeObject(clients);
            File.AppendAllText("CustomerData.txt", JsonConvert.SerializeObject(clients));   
            MessageBox.Show("Thank you for completing the form");
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        // wanted a way to just close the form 
        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // I wanted to do a reset instead of making it part of the submit action.  
        private void buttonReset_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
    }
}
