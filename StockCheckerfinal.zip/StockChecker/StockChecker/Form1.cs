﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Web;
using System.Windows.Forms;
using System.Net;
using System.Data;
using Newtonsoft.Json;

namespace StockChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)  //recall  read from file created to repopulate the empty text boxes if wanting to see previous stocks.
        {
            string line = "";
            StreamReader file = new StreamReader("Ticker.txt");
                while (!file.EndOfStream)
                {
                    line += file.ReadLine() + "&"; 
                }
            string[] newLines = line.Split('&'); 
            textBox1.Text = newLines[0].Split(':')[0].ToString();
            textBox2.Text = newLines[1].Split(':')[0].ToString();
            textBox3.Text = newLines[2].Split(':')[0].ToString();
            textBox4.Text = newLines[3].Split(':')[0].ToString();
            textBox5.Text = newLines[4].Split(':')[0].ToString();
            textBox6.Text = newLines[5].Split(':')[0].ToString();
           

        }

        private void button3_Click(object sender, EventArgs e) //add  add text box entries to file
        {
            var stocks = new List<String>
            {
                textBox1.Text,
                textBox2.Text,
                textBox3.Text,
                textBox4.Text,
                textBox5.Text,
                textBox6.Text
            };
            
            File.WriteAllLines("Ticker.txt", stocks);  
           
        }

        private void button2_Click(object sender, EventArgs e)  //display
        {
            // Create the URL for the stocks entered in the form            
            using (StreamReader sr = new StreamReader("Ticker.txt"))
            {
                string one = "http://stocks.tradingcharts.com/stocks/quotes/"; 
                string two = one + textBox1.Text;
                string three = one + textBox2.Text;
                string four = one + textBox3.Text;
                string five = one + textBox4.Text;
                string six = one + textBox5.Text;
                string seven = one + textBox6.Text;
                string eight = two + three + four + five + six + seven;

                //Open a page for each stock entered on the form
                for (int i = 0; i <= 5; i++)
                {
                    if (i == 0)
                    {
                        Process.Start(two);  
                    }
                    else if (i == 1)
                    {
                        Process.Start(three);  
                    }
                    else if (i == 2)
                    {
                        Process.Start(four);   
                    }
                    else if (i == 3)
                    {
                        Process.Start(five);   
                    }
                    else if (i == 4)
                    {
                        Process.Start(six);   
                    }
                    else 
                    {
                        Process.Start(seven);   
                    }
                }                 

                
                listBox1.Items.Add(two);
                listBox1.Items.Add(three);
                listBox1.Items.Add(four);
                listBox1.Items.Add(five);
                listBox1.Items.Add(six);
                listBox1.Items.Add(seven);

                
            }
            
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("marvin.jpg");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process.Start("http://www.dogsofthedow.com/stock-symbols-list.htm");
        }
    }
}