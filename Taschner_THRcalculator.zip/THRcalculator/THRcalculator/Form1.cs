﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THRcalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void Btncalc_Click(object sender, EventArgs e)
        {
            if (tbfirstnm.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your first name");
                tbfirstnm.Focus();
            }
            else if (tblastnm.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your last name");
                tbfirstnm.Focus();
            }
            else if (tbage.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your age");
                tbfirstnm.Focus();
            }

            string fname = tbfirstnm.Text;
            string lname = tblastnm.Text;
            int age = int.Parse(tbage.Text);
            var Thrvl1 = 220 - age; 
            var Thrvl = Thrvl1 * .70;
            var Thrvh = Thrvl + 14;
            MessageBox.Show($"{fname}, {lname}: Your Chosen target heart rate is between: " + $"{Thrvl} and {Thrvh}");

            //var Thrml = 220 - age - 80 * .50 + 80;
            //var Thrmh = Thrml + 17;
            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrml} and {Thrmh}"); 
                        
            
            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrl} and {Thrh}");
            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrl}" and $"{Thrh}");

        }

        private void Btnreset_Click(object sender, EventArgs e)
        {
            tbfirstnm.Clear();
            tblastnm.Clear();
            tbage.Clear();
        }

        private void Btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (tbfirstnm.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your first name");
                tbfirstnm.Focus();
            }
            else if (tblastnm.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your last name");
                tbfirstnm.Focus();
            }
            else if (tbage.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Please enter your age");
                tbfirstnm.Focus();
            }

            string fname = tbfirstnm.Text;
            string lname = tblastnm.Text;
            int age = int.Parse(tbage.Text);
            //var Thrvl = 220 - age - 80 * .70 + 80;
            //var Thrvh = Thrvl + 14;
            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrvl} and {Thrvh}");

            var Thrml1 = 220 - age;
            var Thrml = Thrml1 * .50;
            //var Thrml = Thrml1 + 70;
            var Thrmh = Thrml + 17;
            MessageBox.Show($"{fname}, {lname}: Your chosen target heart rate is between: " + $"{Thrml} and {Thrmh}");


            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrl} and {Thrh}");
            //MessageBox.Show($"{fname}, {lname}: Your target heart rate for the level chosen is between" + $"{Thrl}" and $"{Thrh}");

        }
    }
    
}


