﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace VitalBuild
{
    [Serializable()]
    public class Data
    {
        public String Sysnum { get; set; }
        public String Letter { get; set; }
        public String Let { get; set; }
        public String Rawhost { get; set; }
        public String Fsq { get; set; }
        public String Sensorpres { get; set; }
        public String Upsques { get; set; }
        public String Sensor1 { get; set; }
        public String Sensor2 { get; set; }
        public String Sensor3 { get; set; }
        public String Sensor4 { get; set; }
        public String Sensor5 { get; set; }
        public String Sensor6 { get; set; }
        public String Sensor7 { get; set; }
        public String Sensor8 { get; set; }
        public String Sensor9 { get; set; }
        public String Sensor10 { get; set; }
        public String Sensor11 { get; set; }
        public String Sensor12 { get; set; }        
        public String Numofsys { get; set; }
        public String Numofsens { get; set; }
        public String Numofups { get; set; }
    }
}
