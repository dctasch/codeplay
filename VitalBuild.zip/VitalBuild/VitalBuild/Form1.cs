﻿using System;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace VitalBuild
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void txtVisNum_TextChanged(object sender, EventArgs e)
        {
            if (txtVisNum.TextLength == 0)
            {
                lblError.Text = "Vis number required";
                lblError.Visible = true;
                txtVisNum.Focus();
            }
        }
        private void txtVisNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comChannel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comChannel_Validated(object sender, EventArgs e)
        {
            if (comChannel.SelectedItem == null)
            {
                lblError.Text = "Channel Count is required";
                lblError.Visible = true;
                comChannel.Focus();
            }
        }
        private void comChannel_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comChannel_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comUps_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comUps_Validated(object sender, EventArgs e)
        {
            if (comUps.SelectedItem == null)
            {
                lblError.Text = "UPS answer required";
                lblError.Visible = true;
                comUps.Focus();
            }
        }
        private void comUps_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comUps_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comFsq_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comFsq_Validated(object sender, EventArgs e)
        {
            if (comFsq.SelectedItem == null)
            {
                lblError.Text = "File Server answer required";
                lblError.Visible = true;
                comFsq.Focus();
            }
        }
        private void comFsq_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comFsq_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comVccL_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comVccL_Validated(object sender, EventArgs e)
        {
            if (comVccL.SelectedItem == null)
            {
                lblError.Text = "Will a Letter be required Yes or No";
                lblError.Visible = true;
                comVccL.Focus();
            }
        }
        private void comVccL_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comVccL_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comRaw_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comRaw_Validated(object sender, EventArgs e)
        {
            if (comRaw.SelectedItem == null)
            {
                lblError.Text = "Will a Raw host be present";
                lblError.Visible = true;
                comRaw.Focus();
            }
        }
        private void comRaw_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comRaw_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comSen_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void comSen_Validated(object sender, EventArgs e)
        {
            if (comSen.SelectedItem == null)
            {
                lblError.Text = "Will sensors be present";
                lblError.Visible = true;
                comSen.Focus();
            }
        }
        private void comSen_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comSen_Leave(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
        private void comNumSen_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        private void comSensor1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor8_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor9_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor10_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor11_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor12_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }

        private void comNumUps_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comNumUps_Validated(object sender, EventArgs e)
        {
            //if (comNumUps.SelectedItem == null)
            //{
            //    lblError.Text = "Number of UPS required";
            //    lblError.Visible = true;
            //    comNumUps.Focus();
            //}
        }
        private void comNumUps_KeyPress(object sender, KeyPressEventArgs e)
        {
            //lblError.Text = "";
            //lblError.Hide();
        }
        private void comboVcc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comboVcc_Validated(object sender, EventArgs e)
        {
            //if (comboVcc.SelectedItem == null)
            //{
            //    lblError.Text = "Please select the appropriate letter";
            //    lblError.Visible = true;
            //    comboVcc.Focus();
            //}
        }
        private void comboVcc_KeyPress(object sender, KeyPressEventArgs e)
        {
            //lblError.Text = "";
            //lblError.Hide();
        }
        private void CreateBtn_Click(object sender, EventArgs e)
        {
            Data tx = new Data();
            tx.Sysnum = txtVisNum.Text;
            tx.Fsq = comFsq.Text;
            tx.Letter = comVccL.Text;
            tx.Let = comboVcc.Text;
            tx.Rawhost = comRaw.Text;
            tx.Numofsys = comChannel.Text;
            tx.Sensorpres = comSen.Text;
            tx.Numofsens = comSen.Text;
            tx.Sensor1 = comSensor1.Text;
            tx.Sensor2 = comSensor2.Text;
            tx.Sensor3 = comSensor3.Text;
            tx.Sensor4 = comSensor4.Text;
            tx.Sensor5 = comSensor5.Text;
            tx.Sensor6 = comSensor6.Text;
            tx.Sensor7 = comSensor7.Text;
            tx.Sensor8 = comSensor8.Text;
            tx.Sensor9 = comSensor9.Text;
            tx.Sensor10 = comSensor10.Text;
            tx.Sensor11 = comSensor11.Text;
            tx.Sensor12 = comSensor12.Text;
            tx.Upsques = comUps.Text;
            tx.Numofups = comNumUps.Text;

            // Write to XML
            XmlSerializer writer = new XmlSerializer(typeof(Data));
            using (FileStream file = File.OpenWrite("C:\\temp\\Visbuild.xml"))
            {
                writer.Serialize(file, tx);
            }
        }        
    }              
}

//Application designer:  David (Tash) Taschner
//Design Date: April 2019.