﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace VitalBuild
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtVisNum_TextChanged(object sender, EventArgs e)
        {
            if (txtVisNum.TextLength == 0)
            {
                lblError.Text = "Vis number required";
                lblError.Visible = true;
                txtVisNum.Focus();
            }
        }     
            
        private void comChannel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comUps_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comFsq_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comVccL_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comRaw_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSen_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comNumSen_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comSensor1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor8_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor9_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor10_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor11_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comSensor12_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {

        }

        private void comNumUps_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comboVcc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            Data tx = new Data();
            tx.Sysnum = txtVisNum.Text;
            tx.Fsq = comFsq.Text;
            tx.Letter = comVccL.Text;
            tx.Let = comboVcc.Text;
            tx.Rawhost = comRaw.Text;
            tx.Numofsys = comChannel.Text;
            tx.Sensorpres = comSen.Text;
            tx.Numofsens = comSen.Text;
            tx.Sensor1 = comSensor1.Text;
            tx.Sensor2 = comSensor2.Text;
            tx.Sensor3 = comSensor3.Text;
            tx.Sensor4 = comSensor4.Text;
            tx.Sensor5 = comSensor5.Text;
            tx.Sensor6 = comSensor6.Text;
            tx.Sensor7 = comSensor7.Text;
            tx.Sensor8 = comSensor8.Text;
            tx.Sensor9 = comSensor9.Text;
            tx.Sensor10 = comSensor10.Text;
            tx.Sensor11 = comSensor11.Text;
            tx.Sensor12 = comSensor12.Text;
            tx.Upsques = comUps.Text;
            tx.Numofups = comNumUps.Text;
                       
            // Write to XML
            XmlSerializer writer = new XmlSerializer(typeof(Data));
            using (FileStream file = File.OpenWrite("C:\\temp\\Visbuild.xml"))
            {
                writer.Serialize(file, tx);
            }
        }

        private void txtVisNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            lblError.Text = "";
            lblError.Hide();
        }
    }
            //if (cbSenno.Checked)
            //{
            //    numSen.Enabled = false;
            //    comSensor1.Enabled = false;
            //    comSensor2.Enabled = false;
            //    comSensor3.Enabled = false;
            //    comSensor4.Enabled = false;
            //    comSensor5.Enabled = false;
            //    comSensor6.Enabled = false;
            //    comSensor7.Enabled = false;
            //    comSensor8.Enabled = false;
            //    comSensor9.Enabled = false;
            //    comSensor10.Enabled = false;
            //    comSensor11.Enabled = false;
            //    comSensor12.Enabled = false;
            //    else
        //    {
        //        numSen.Enabled = true;
        //        comSensor1.Enabled = true;
        //        comSensor2.Enabled = true;
        //        comSensor3.Enabled = true;
        //        comSensor4.Enabled = true;
        //        comSensor5.Enabled = true;
        //        comSensor6.Enabled = true;
        //        comSensor7.Enabled = true;
        //        comSensor8.Enabled = true;
        //        comSensor9.Enabled = true;
        //        comSensor10.Enabled = true;
        //        comSensor11.Enabled = true;
        //        comSensor12.Enabled = true;
        //    }
        //}

           

       
}

