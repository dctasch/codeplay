﻿using System;

namespace VitalBuild
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comNumUps = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comUps = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.comChannel = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comNumSen = new System.Windows.Forms.ComboBox();
            this.comSen = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.CreateBtn = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comSensor12 = new System.Windows.Forms.ComboBox();
            this.comSensor6 = new System.Windows.Forms.ComboBox();
            this.comSensor11 = new System.Windows.Forms.ComboBox();
            this.comSensor5 = new System.Windows.Forms.ComboBox();
            this.comSensor10 = new System.Windows.Forms.ComboBox();
            this.comSensor4 = new System.Windows.Forms.ComboBox();
            this.comSensor9 = new System.Windows.Forms.ComboBox();
            this.comSensor3 = new System.Windows.Forms.ComboBox();
            this.comSensor8 = new System.Windows.Forms.ComboBox();
            this.comSensor2 = new System.Windows.Forms.ComboBox();
            this.comSensor7 = new System.Windows.Forms.ComboBox();
            this.comSensor1 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comRaw = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comVccL = new System.Windows.Forms.ComboBox();
            this.comboVcc = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtVisNum = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comFsq = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.AliceBlue;
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.lblError);
            this.groupBox1.Controls.Add(this.comChannel);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtVisNum);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(12, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(649, 366);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comNumUps);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.comUps);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Location = new System.Drawing.Point(9, 204);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(122, 100);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // comNumUps
            // 
            this.comNumUps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comNumUps.FormattingEnabled = true;
            this.comNumUps.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comNumUps.Location = new System.Drawing.Point(63, 79);
            this.comNumUps.Name = "comNumUps";
            this.comNumUps.Size = new System.Drawing.Size(59, 21);
            this.comNumUps.TabIndex = 23;
            this.comNumUps.SelectedIndexChanged += new System.EventHandler(this.comNumUps_SelectedIndexChanged);
            this.comNumUps.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comNumUps_KeyPress);
            this.comNumUps.Validated += new System.EventHandler(this.comNumUps_Validated);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Install UPS Yes or No";
            // 
            // comUps
            // 
            this.comUps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comUps.FormattingEnabled = true;
            this.comUps.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comUps.Location = new System.Drawing.Point(6, 29);
            this.comUps.Name = "comUps";
            this.comUps.Size = new System.Drawing.Size(62, 21);
            this.comUps.TabIndex = 22;
            this.comUps.SelectedIndexChanged += new System.EventHandler(this.comUps_SelectedIndexChanged);
            this.comUps.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comUps_KeyPress);
            this.comUps.Leave += new System.EventHandler(this.comUps_Leave);
            this.comUps.Validated += new System.EventHandler(this.comUps_Validated);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "How Many UPS\'";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(6, 16);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 27;
            // 
            // comChannel
            // 
            this.comChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comChannel.FormattingEnabled = true;
            this.comChannel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comChannel.Location = new System.Drawing.Point(9, 142);
            this.comChannel.Name = "comChannel";
            this.comChannel.Size = new System.Drawing.Size(59, 21);
            this.comChannel.TabIndex = 3;
            this.comChannel.SelectedIndexChanged += new System.EventHandler(this.comChannel_SelectedIndexChanged);
            this.comChannel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comChannel_KeyPress);
            this.comChannel.Leave += new System.EventHandler(this.comChannel_Leave);
            this.comChannel.Validated += new System.EventHandler(this.comChannel_Validated);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(9, 310);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(385, 50);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comNumSen);
            this.panel1.Controls.Add(this.comSen);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.ClearBtn);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.CreateBtn);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.comSensor12);
            this.panel1.Controls.Add(this.comSensor6);
            this.panel1.Controls.Add(this.comSensor11);
            this.panel1.Controls.Add(this.comSensor5);
            this.panel1.Controls.Add(this.comSensor10);
            this.panel1.Controls.Add(this.comSensor4);
            this.panel1.Controls.Add(this.comSensor9);
            this.panel1.Controls.Add(this.comSensor3);
            this.panel1.Controls.Add(this.comSensor8);
            this.panel1.Controls.Add(this.comSensor2);
            this.panel1.Controls.Add(this.comSensor7);
            this.panel1.Controls.Add(this.comSensor1);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(400, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(228, 344);
            this.panel1.TabIndex = 19;
            // 
            // comNumSen
            // 
            this.comNumSen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comNumSen.FormattingEnabled = true;
            this.comNumSen.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comNumSen.Location = new System.Drawing.Point(104, 30);
            this.comNumSen.Name = "comNumSen";
            this.comNumSen.Size = new System.Drawing.Size(42, 21);
            this.comNumSen.TabIndex = 31;
            this.comNumSen.SelectedIndexChanged += new System.EventHandler(this.comNumSen_SelectedIndexChanged);
            // 
            // comSen
            // 
            this.comSen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSen.FormattingEnabled = true;
            this.comSen.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comSen.Location = new System.Drawing.Point(137, 7);
            this.comSen.Name = "comSen";
            this.comSen.Size = new System.Drawing.Size(59, 21);
            this.comSen.TabIndex = 30;
            this.comSen.SelectedIndexChanged += new System.EventHandler(this.comSen_SelectedIndexChanged);
            this.comSen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comSen_KeyPress);
            this.comSen.Leave += new System.EventHandler(this.comSen_Leave);
            this.comSen.Validated += new System.EventHandler(this.comSen_Validated);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(117, 259);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 13);
            this.label24.TabIndex = 26;
            this.label24.Text = "Sensor12";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(117, 221);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 13);
            this.label23.TabIndex = 26;
            this.label23.Text = "Sensor11";
            // 
            // ClearBtn
            // 
            this.ClearBtn.Location = new System.Drawing.Point(148, 318);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(71, 23);
            this.ClearBtn.TabIndex = 62;
            this.ClearBtn.Text = "Clear Form";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(117, 185);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 13);
            this.label22.TabIndex = 26;
            this.label22.Text = "Sensor10";
            // 
            // CreateBtn
            // 
            this.CreateBtn.Location = new System.Drawing.Point(3, 318);
            this.CreateBtn.Name = "CreateBtn";
            this.CreateBtn.Size = new System.Drawing.Size(132, 23);
            this.CreateBtn.TabIndex = 61;
            this.CreateBtn.Text = "Create Build File";
            this.CreateBtn.UseVisualStyleBackColor = true;
            this.CreateBtn.Click += new System.EventHandler(this.CreateBtn_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(117, 148);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 13);
            this.label21.TabIndex = 26;
            this.label21.Text = "Sensor9";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(117, 110);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 13);
            this.label20.TabIndex = 26;
            this.label20.Text = "Sensor8";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(117, 72);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 26;
            this.label19.Text = "Sensor7";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 259);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 13);
            this.label18.TabIndex = 26;
            this.label18.Text = "Sensor6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Install Sensors Yes or No";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 221);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "Sensor5";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 185);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 13);
            this.label16.TabIndex = 26;
            this.label16.Text = "Sensor4";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Sensor3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Sensor2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Sensor1";
            // 
            // comSensor12
            // 
            this.comSensor12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor12.FormattingEnabled = true;
            this.comSensor12.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor12.Location = new System.Drawing.Point(120, 275);
            this.comSensor12.Name = "comSensor12";
            this.comSensor12.Size = new System.Drawing.Size(99, 21);
            this.comSensor12.TabIndex = 43;
            this.comSensor12.SelectedIndexChanged += new System.EventHandler(this.comSensor12_SelectedIndexChanged);
            // 
            // comSensor6
            // 
            this.comSensor6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor6.FormattingEnabled = true;
            this.comSensor6.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor6.Location = new System.Drawing.Point(6, 275);
            this.comSensor6.Name = "comSensor6";
            this.comSensor6.Size = new System.Drawing.Size(99, 21);
            this.comSensor6.TabIndex = 37;
            this.comSensor6.SelectedIndexChanged += new System.EventHandler(this.comSensor6_SelectedIndexChanged);
            // 
            // comSensor11
            // 
            this.comSensor11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor11.FormattingEnabled = true;
            this.comSensor11.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor11.Location = new System.Drawing.Point(120, 234);
            this.comSensor11.Name = "comSensor11";
            this.comSensor11.Size = new System.Drawing.Size(99, 21);
            this.comSensor11.TabIndex = 42;
            this.comSensor11.SelectedIndexChanged += new System.EventHandler(this.comSensor11_SelectedIndexChanged);
            // 
            // comSensor5
            // 
            this.comSensor5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor5.FormattingEnabled = true;
            this.comSensor5.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor5.Location = new System.Drawing.Point(6, 234);
            this.comSensor5.Name = "comSensor5";
            this.comSensor5.Size = new System.Drawing.Size(99, 21);
            this.comSensor5.TabIndex = 36;
            this.comSensor5.SelectedIndexChanged += new System.EventHandler(this.comSensor5_SelectedIndexChanged);
            // 
            // comSensor10
            // 
            this.comSensor10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor10.FormattingEnabled = true;
            this.comSensor10.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor10.Location = new System.Drawing.Point(120, 197);
            this.comSensor10.Name = "comSensor10";
            this.comSensor10.Size = new System.Drawing.Size(99, 21);
            this.comSensor10.TabIndex = 41;
            this.comSensor10.SelectedIndexChanged += new System.EventHandler(this.comSensor10_SelectedIndexChanged);
            // 
            // comSensor4
            // 
            this.comSensor4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor4.FormattingEnabled = true;
            this.comSensor4.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor4.Location = new System.Drawing.Point(6, 197);
            this.comSensor4.Name = "comSensor4";
            this.comSensor4.Size = new System.Drawing.Size(99, 21);
            this.comSensor4.TabIndex = 35;
            this.comSensor4.SelectedIndexChanged += new System.EventHandler(this.comSensor4_SelectedIndexChanged);
            // 
            // comSensor9
            // 
            this.comSensor9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor9.FormattingEnabled = true;
            this.comSensor9.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor9.Location = new System.Drawing.Point(120, 161);
            this.comSensor9.Name = "comSensor9";
            this.comSensor9.Size = new System.Drawing.Size(99, 21);
            this.comSensor9.TabIndex = 40;
            this.comSensor9.SelectedIndexChanged += new System.EventHandler(this.comSensor9_SelectedIndexChanged);
            // 
            // comSensor3
            // 
            this.comSensor3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor3.FormattingEnabled = true;
            this.comSensor3.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor3.Location = new System.Drawing.Point(6, 161);
            this.comSensor3.Name = "comSensor3";
            this.comSensor3.Size = new System.Drawing.Size(99, 21);
            this.comSensor3.TabIndex = 34;
            this.comSensor3.SelectedIndexChanged += new System.EventHandler(this.comSensor3_SelectedIndexChanged);
            // 
            // comSensor8
            // 
            this.comSensor8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor8.FormattingEnabled = true;
            this.comSensor8.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor8.Location = new System.Drawing.Point(120, 124);
            this.comSensor8.Name = "comSensor8";
            this.comSensor8.Size = new System.Drawing.Size(99, 21);
            this.comSensor8.TabIndex = 39;
            this.comSensor8.SelectedIndexChanged += new System.EventHandler(this.comSensor8_SelectedIndexChanged);
            // 
            // comSensor2
            // 
            this.comSensor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor2.FormattingEnabled = true;
            this.comSensor2.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor2.Location = new System.Drawing.Point(6, 124);
            this.comSensor2.Name = "comSensor2";
            this.comSensor2.Size = new System.Drawing.Size(99, 21);
            this.comSensor2.TabIndex = 33;
            this.comSensor2.SelectedIndexChanged += new System.EventHandler(this.comSensor2_SelectedIndexChanged);
            // 
            // comSensor7
            // 
            this.comSensor7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor7.FormattingEnabled = true;
            this.comSensor7.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor7.Location = new System.Drawing.Point(120, 86);
            this.comSensor7.Name = "comSensor7";
            this.comSensor7.Size = new System.Drawing.Size(99, 21);
            this.comSensor7.TabIndex = 38;
            this.comSensor7.SelectedIndexChanged += new System.EventHandler(this.comSensor7_SelectedIndexChanged);
            // 
            // comSensor1
            // 
            this.comSensor1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comSensor1.FormattingEnabled = true;
            this.comSensor1.Items.AddRange(new object[] {
            "vars",
            "hud",
            "mios",
            "rcam",
            "lcam",
            "rvis",
            "lvis",
            "swir",
            "mwir",
            "lltv",
            "ctv",
            "ir"});
            this.comSensor1.Location = new System.Drawing.Point(6, 86);
            this.comSensor1.Name = "comSensor1";
            this.comSensor1.Size = new System.Drawing.Size(99, 21);
            this.comSensor1.TabIndex = 32;
            this.comSensor1.SelectedIndexChanged += new System.EventHandler(this.comSensor1_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "    Select the Sensors needed";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "How Many Sensors";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comRaw);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Location = new System.Drawing.Point(181, 237);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(162, 63);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            // 
            // comRaw
            // 
            this.comRaw.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comRaw.FormattingEnabled = true;
            this.comRaw.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comRaw.Location = new System.Drawing.Point(6, 31);
            this.comRaw.Name = "comRaw";
            this.comRaw.Size = new System.Drawing.Size(59, 21);
            this.comRaw.TabIndex = 27;
            this.comRaw.SelectedIndexChanged += new System.EventHandler(this.comRaw_SelectedIndexChanged);
            this.comRaw.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comRaw_KeyPress);
            this.comRaw.Leave += new System.EventHandler(this.comRaw_Leave);
            this.comRaw.Validated += new System.EventHandler(this.comRaw_Validated);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, -13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Raw Server Present";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Raw Host Present Yes or No";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comVccL);
            this.groupBox4.Controls.Add(this.comboVcc);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(181, 107);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(162, 101);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            // 
            // comVccL
            // 
            this.comVccL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comVccL.FormattingEnabled = true;
            this.comVccL.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comVccL.Location = new System.Drawing.Point(9, 29);
            this.comVccL.Name = "comVccL";
            this.comVccL.Size = new System.Drawing.Size(59, 21);
            this.comVccL.TabIndex = 25;
            this.comVccL.SelectedIndexChanged += new System.EventHandler(this.comVccL_SelectedIndexChanged);
            this.comVccL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comVccL_KeyPress);
            this.comVccL.Leave += new System.EventHandler(this.comVccL_Leave);
            this.comVccL.Validated += new System.EventHandler(this.comVccL_Validated);
            // 
            // comboVcc
            // 
            this.comboVcc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboVcc.FormattingEnabled = true;
            this.comboVcc.Items.AddRange(new object[] {
            "a",
            "b",
            "c",
            "d",
            "e",
            "f"});
            this.comboVcc.Location = new System.Drawing.Point(104, 80);
            this.comboVcc.Name = "comboVcc";
            this.comboVcc.Size = new System.Drawing.Size(58, 21);
            this.comboVcc.TabIndex = 26;
            this.comboVcc.SelectedIndexChanged += new System.EventHandler(this.comboVcc_SelectedIndexChanged);
            this.comboVcc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboVcc_KeyPress);
            this.comboVcc.Validated += new System.EventHandler(this.comboVcc_Validated);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "VCC Letter to use";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "VCC Letter Required Yes or No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Number of Channels";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Vis Number to Assign";
            // 
            // txtVisNum
            // 
            this.txtVisNum.Location = new System.Drawing.Point(9, 58);
            this.txtVisNum.MaxLength = 4;
            this.txtVisNum.Name = "txtVisNum";
            this.txtVisNum.Size = new System.Drawing.Size(62, 20);
            this.txtVisNum.TabIndex = 2;
            this.txtVisNum.TextChanged += new System.EventHandler(this.txtVisNum_TextChanged);
            this.txtVisNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisNum_KeyPress);
            this.txtVisNum.Validated += new System.EventHandler(this.txtVisNum_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comFsq);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(181, 32);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(162, 69);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // comFsq
            // 
            this.comFsq.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comFsq.FormattingEnabled = true;
            this.comFsq.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comFsq.Location = new System.Drawing.Point(9, 29);
            this.comFsq.Name = "comFsq";
            this.comFsq.Size = new System.Drawing.Size(59, 21);
            this.comFsq.TabIndex = 24;
            this.comFsq.SelectedIndexChanged += new System.EventHandler(this.comFsq_SelectedIndexChanged);
            this.comFsq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comFsq_KeyPress);
            this.comFsq.Leave += new System.EventHandler(this.comFsq_Leave);
            this.comFsq.Validated += new System.EventHandler(this.comFsq_Validated);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Install File Server  Yes or No";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.SeaShell;
            this.richTextBox1.Font = new System.Drawing.Font("Century Schoolbook", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(12, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(649, 70);
            this.richTextBox1.TabIndex = 70;
            this.richTextBox1.TabStop = false;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(504, 26);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Vital Build Input Form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        //private void label7_Click(object sender, EventArgs e)
        //{
        //    throw new NotImplementedException();
        //}

        //private void CreateBtn_Click(object sender, EventArgs e)
        //{
        //    throw new NotImplementedException();
        //}

        //private void comboVcc_SelectedIndexChanged(object sender, EventArgs e)
        //{
            
        //}

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtVisNum;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Button CreateBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboVcc;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comSensor12;
        private System.Windows.Forms.ComboBox comSensor6;
        private System.Windows.Forms.ComboBox comSensor11;
        private System.Windows.Forms.ComboBox comSensor5;
        private System.Windows.Forms.ComboBox comSensor10;
        private System.Windows.Forms.ComboBox comSensor4;
        private System.Windows.Forms.ComboBox comSensor9;
        private System.Windows.Forms.ComboBox comSensor3;
        private System.Windows.Forms.ComboBox comSensor8;
        private System.Windows.Forms.ComboBox comSensor2;
        private System.Windows.Forms.ComboBox comSensor7;
        private System.Windows.Forms.ComboBox comSensor1;
        private System.Windows.Forms.ComboBox comChannel;
        private System.Windows.Forms.ComboBox comNumUps;
        private System.Windows.Forms.ComboBox comUps;
        private System.Windows.Forms.ComboBox comNumSen;
        private System.Windows.Forms.ComboBox comSen;
        private System.Windows.Forms.ComboBox comRaw;
        private System.Windows.Forms.ComboBox comVccL;
        private System.Windows.Forms.ComboBox comFsq;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

